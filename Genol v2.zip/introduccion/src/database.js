const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/Genol',{
     useCreateIndex:true,
     useNewUrlParser: true,
     useFindAndModify: false,
     useUnifiedTopology: true
})
   .then(db =>console.log('db connected'))
   .catch(err => console.error(err));

   /* Tenemos nuestra conexion inicializada siempre con el nombre de la base de datso Genol , para qe siempre sea la misma+
    este creada o no */ 