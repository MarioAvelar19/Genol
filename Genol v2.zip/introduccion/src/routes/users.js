const express = require('express');
const router = express.Router();
const User = require('../models/user');
const passport = require('passport');

router.get('/users/signin',(req,res) =>{
    res.render('users/signin');
})

router.get('/users/signup',(req,res) =>{
    res.render('users/signup');
})
router.post('/users/signin',passport.authenticate('local',{
    successRedirect : '/notes',
    failureRedirect : '/users/signin',
    failureFlash: true
}))

router.post('/users/signup', async (req,res)=>{
    const {name,email,password,confirm_password}=req.body;
     
    const errors=[];

    if(name.length <= 0){
        errors.push({text:'Favor de insertar tu nombre'})
    }
    if(email.length <= 0){
        errors.push({text:'Favor de insertar tu email'})
    }
    if(password.length <= 0){
        errors.push({text:'Favor de insertar tu contraseña'})
    }
    if(confirm_password.length <= 0){
        errors.push({text:'Favor de insertar tu la confirmacion de contraseña'})
    }
    if(password != confirm_password){
        errors.push({text:'Contraseña diferente de la Confirmacion de Contraseña'});
    }
    if(password.length < 4){
        errors.push({text:'Contraseña debe ser mayor de 4 digitos'});
    }
    if(errors.length > 0){
        res.render('users/signup',{
           errors,
           name,
           email,
           password,
           confirm_password 
        });
    }else{
        const emailUser= await User.findOne({email: email});
        if(emailUser){
            req.flash('error_msg','EL Email esta ya en uso , Intente con otro ');
            res.redirect('/users/signup');
        }else{
           const newUser = new User({name,email,password});
           newUser.password=await newUser.encryptPassword(password);
           await newUser.save();
           req.flash('success_msg','Registro Exitoso');
           res.redirect('/users/signin');
        }
        
    }
});

router.get('/users/logout',(req,res)=>{
   req.logOut();
   res.redirect('/');
});
module.exports = router;