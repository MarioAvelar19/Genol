const { Router } = require('express');
const express = require('express');
const router = express.Router();

const Producto = require('../models/products');
const { isAuthenticated } = require('../helpers/auth');

router.get('/notes/add', isAuthenticated, (req,res) =>{
        res.render('notes/new-product');
});

router.post('/notes/new-product', isAuthenticated ,async (req,res) =>{
    const {nombreProd , description , price } = req.body;
    const errors = [];
    if(!nombreProd){
        errors.push({text: 'Inserte Nombre del producto'});
    }
    if(!description){
        errors.push({text : 'Inserte Description del producto'});
    }
    if(!price){
        errors.push({text: 'Inserte precio del producto '});
    }
    if(errors.length > 0 ){
        res.render('notes/new-product',{
            errors,
            nombreProd,
            description,
            price
        });
    }else{
        const NewProd= new Producto({nombreProd,description,price});
        NewProd.user = req.user.id;
        await NewProd.save();
        req.flash('success_msg','Producto agregado satisfactoriamente');
        res.redirect('/notes');
    }
    
});

router.get('/notes',isAuthenticated, async (req,res)=>{
   const Prods =  await Producto.find({user:req.user.id}).sort({date:'desc'});
   res.render('notes/all-productos', { Prods });
})

router.get('/notes/edit/:id',isAuthenticated,async (req,res) =>{
    const Prod = await Producto.findById(req.params.id)
    res.render('notes/edit-producto',{Prod })
})

router.put('/notes/edit-producto/:id',isAuthenticated, async (req,res)=>{
    const {nombreProd , description , price }=  req.body;
    await Producto.findByIdAndUpdate(req.params.id,{nombreProd,description,price})
    req.flash('success_msg','Producto actualizado exitosamente')
    res.redirect('/notes')
})

router.delete('/notes/delete/:id', isAuthenticated,async(req,res)=>{
    await Producto.findByIdAndDelete(req.params.id);
    req.flash('success_msg','Producto eliminado exitosamente')
    res.redirect('/notes')
})

module.exports = router;