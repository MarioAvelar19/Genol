const mongoose=require('mongoose');
const bcrypt= require('bcryptjs');

const { Schema } = mongoose; 

const UserSchema = new Schema({
    name:{ type:String , required: true},
    email: { type: String, required: true},
    password: { type: String , required : true},
    date: { type: Date, default: Date.now}
});

/* Usamos el modulo encrypt password debido a que queremos tener siempre las contraseñas aseguradas y encryptadas*/ 
UserSchema.methods.encryptPassword = async (password) => {
  const salt =  await  bcrypt.genSalt(10);
  const hash = bcrypt.hash(password,salt);
  return hash;
};

UserSchema.methods.matchPassword = async function(password){
     return  await bcrypt.compare(password, this.password);
};

/* Creamos el modelos que seria la definicion de datos de la collecion que sube as mongo
en este caso user, y sus tipos de datos usando Mongoose*/

module.exports = mongoose.model('User',UserSchema);