const mongoose = require('mongoose');

const { Schema }= mongoose;

const ProdSchema = new Schema({
     nombreProd:{type: String,required:true},
     description: {type:String,required:true},
     date:{type:Date, default: Date.now},
     user: { type: String},
     price:{ type: Number, requiered:true}
})

/* Creamos el modelos que seria la definicion de datos de la collecion que sube as mongo
en este caso producto, y sus tipos de datos usando Mongoose*/
module.exports = mongoose.model('Producto',ProdSchema)